import { Album } from "./Album";

export class Artist{
    name:string;
    id:string;
    albums:Album[]=[];
}