import { Artist } from "@ngx-spotify-api/core";

export class Album{
    id:string;
    artist:Artist;
}