const {Howl, Howler} = require('howler');

Howler.autoUnlock=false;

let sound=new Howl({
    src:['mv-seventeen-dont-wanna-cry.mp3'],
    loop:false,
    autoplay:false,
    volume:0.2

});

sound.play();