import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SpotifyService {

  devant: HttpHeaders=new HttpHeaders({
    'Authorization': 'Bearer BQAj33q5jtymxKMhSCe9PiWzYCx5TxCf2MyCYGHWEkfGVTyk4Qy-bw_IdCbUoqF1Q3DSGXoKD_ttz9HRSAzPLD-RFiWJClWOwHPPtC67me088PndvlrkuX8bbGC1OynDu6cpyH0dTjobBV3kt7R6MJHUgIuLHppaPVyFs37L5YcInKpP3tclIEf__CGAoAG2BzuHdC_5-Mg5SgPlEX5blWfBq0g1f7n77S4htMJtrLawOFOwtKnClWa_yQ6G_Dtxfdu9fExhCLIwuw0LadcUxtcy'
  })

  constructor(private http:HttpClient) { }

  getAlbums(){
    return this.http.get('https://api.spotify.com/v1/albums',
                        {headers: this.devant});
  }

  getReleases(){
    return this.http.get("https://api.spotify.com/v1/browse/new-releases",
                        {headers: this.devant});
  }

  getArtists(){
    return this.http.get("https://api.spotify.com/v1/artists",
                        {headers: this.devant})
  }

  getPlaylists(){
    return this.http.get("https://api.spotify.com/v1/me/playlists",
                        {headers: this.devant});
  }

  getOnceAlbum(id:string){
    return this.http.get("https://api.spotify.com/v1/albums/"+id,
                    {headers: this.devant});
  }

  getOnceAritist(id:string){
    return this.http.get("https://api.spotify.com/v1/artists/"+id,
                    {headers: this.devant});
  }

  getOncePlaylist(id:string){
    return this.http.get("https://api.spotify.com/v1//"+id,
                    {headers: this.devant});
  }

  getOnceTrack(id:string){
    return this.http.get("https://api.spotify.com/v1/tracks/"+id,
                    {headers: this.devant});
  }

  getSearch(queryString:string){
    return this.http.get("https://api.spotify.com/v1/search?q="+queryString+"&type=album&market=FR&limit=10&offset=5",
                        {headers: this.devant});
  }
}
